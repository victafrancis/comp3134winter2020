
<?php  
  
echo readfile("storedxss.txt"); 
  
?> 